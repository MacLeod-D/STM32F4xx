/*
========================================================================
  STM32_F4_Timer1_InputCaptureISR

  (C) 2020 Helmut Weber

========================================================================
*/

// from https://www.youtube.com/watch?v=J_Lg6PpvX9Q

#ifndef DAC_H
#define DAC_H

#include "Defines.h"

#ifdef _STM32F4_

void GPIO_Config();

void DAC1_Config();

void DAC1_Start();

void DAC2_Start();

//void DAC1_Out8( uint32_t val);
//
//void DAC1_Out12( uint32_t val);

#define DAC1_Out8(val)  DAC->DHR8R1=val

#define DAC1_Out12(val) DAC->DHR12R1=val
#endif // F4

#endif
