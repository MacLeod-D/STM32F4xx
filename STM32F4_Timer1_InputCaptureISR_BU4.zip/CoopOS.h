/*
========================================================================
  STM32_F4_Timer1_InputCaptureISR

  (C) 2020 Helmut Weber

========================================================================
*/

#ifndef COOPOS_H
#define COOPOS_H


#include <stdint.h>
#include <Arduino.h>


#include "Config.h"
#include "Defines.h"

//#include "CoopOS_Tasks.h"





#define SetPB13()   GPIOB->regs->ODR |= (1<<13)
#define ClearPB13() GPIOB->regs->BRR |= (1<<13)  // 0-15



extern volatile uint32_t SchedCount;


enum state        { READY, DELAYED, BLOCKED, WAITSIG, WAITRES };


// Task Control Block - all infos belonging to a task

struct tcb {

    /** \details Is the Task-Handle returned by TaskInit()*/
    uint8_t     ID;

    /** \details Freely selectable name. Only used for Task-Lists */
    char        *Name;

    /** \details Pointer to function which is the task. void * is a pointer to a parameter. May be NULL*/
    void        (*Func)(void *);

    /** \details Is not used here. If INTERNAL_PRIO is defined: Priority is set with position in TaskInit(),<br>
      First defined Tasks have highest priority.
    */
    uint8_t     Priority;       // Priorität // reserved

    /** \details timestamp (µs) of last call of the task. Is used for delays. */
    uint64_t    LastCalled;

    /** \details Delay in µs since LastCalled - state is DELAYED */
    uint64_t    Delay;           // Delay in Microsconds

    /** \details State of Task:  READY, DELAYED, BLOCKED, WAITSIG, WAITRES */
    uint8_t     Status;          // Status: READY, DELAYED

    /** \details If State==WAITSIG this is the Signal to wait for */
    uint8_t     Signal;         // wait for a signal

    /** \details If State==WAITRES this is the Resource to wait for */
    uint8_t     Resource;       // wait for a resource

    /** \details Incremented for each call */
    uint32_t    Count;         // count calls

    /** \details This is (an optional) pointer to a parameter. If set with TaskInit() it is used every time<br>
      this task is called. It must be converted to something meaningful inside the task.<br>
      Could be used to manipulate the behavior of the task (for instance delay-times) from other Tasks or Interrupts
    */
    void        *Param;
};


typedef struct tcb TCB;

// Define a Task
int TaskInit(char *name, void (*f)(void *p), uint8_t priority, uint8_t stat, uint32_t del, void *param) ;

void TaskList( char *buf);

//Run all defined tasks - must be called in a loop
void Scheduler();


#endif
