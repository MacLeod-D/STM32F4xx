/*
========================================================================
  STM32_F4_Timer1_InputCaptureISR

  (C) 2020 Helmut Weber

========================================================================
*/




extern void MySer_Task(void *);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <itoa.h>
#include <Arduino.h>

#include "CoopOS_Defines.h"
#include "Config.h"

#ifdef _MYSER_

#include "MySerial.h"

//template<class T> inline Print &operator <<(Print &stream, T arg) {
//    stream.print(arg);
//    return stream;
//}


// MySerial:
// Redirect Serial to any destination

volatile int SerHead;
volatile int SerTail;

//#define SER_BUF_MAX 500
char OutBuf[SER_BUF_MAX];



#include "MySerial.h"

#ifdef _RTOS_
//#include <Arduino_FreeRTOS.h>
#endif



/**
 * \brief
 * "_itoa"<br>
 * This is the selfmade conversion from unsigned int to ascii-string<br>
 * digits are the number of digits behind the"."
 */
char *_itoa(unsigned int l) {
    static char b[31];
    static char const digit[] = "0123456789";
    char* p = b+28;;
    uint8_t cnt=0;

    *p = 0;
    *(p+1)=0;

    do { //Move back, inserting digits as u go
        cnt++;
        if (cnt==4) {
            p--;
            *p='.';
            cnt=1;
        }
        p--;
        *p = digit[l % 10l];
        //p--;                             // just to proof we are using this _ltoa
        //*p = 'l';
        l = l/10l;
    } while(l);
    return p; // return result as a pointer to string
}



/**
 * \brief
 * "_ltoa"<br>
 * This is the selfmade conversion from unsigned long to ascii-string<br>
 * digits are the number of digits behind the"."
 */
char *_ltoa(unsigned long l) {
    static char b[31];
    static char const digit[] = "0123456789";
    char* p = b+28;;
    uint8_t cnt=0;

    *p = 0;
    *(p+1)=0;

    do { //Move back, inserting digits as u go
        cnt++;
        if (cnt==4) {
            p--;
            *p='.';
            cnt=1;
        }
        p--;
        *p = digit[l % 10l];
        //p--;                             // just to proof we are using this _ltoa
        //*p = 'l';
        l = l/10l;
    } while(l);
    return p; // return result as a pointer to string
}


/**
 * \brief
 * "_lltoa"<br>
 * This is the selfmade conversion from unsigned long to ascii-string<br>
 * digits are the number of digits behind the"."
 */
char *_lltoa(unsigned long l) {
    static char b[31];
    static char const digit[] = "0123456789";
    char* p = b+28;
    uint8_t cnt;

    *p = 0;
    *(p+1)=0;
    cnt=0;

    do { //Move back, inserting digits as u go
        cnt++;
        if (cnt==4) {
            p--;
            *p='.';
            cnt=1;
        }
        p--;
        *p = digit[l % 10l];
        l = l/10l;
    } while(l);
    return p; // return result as a pointer to string
}


/**
 * \brief
 * "ftoa"<br>
 * This is the selfmade conversion from float to ascii-string<br>
 * digits are the number of digits behind the"."
 *
 * f MUST be greater 0.1 !!!!!!!!!!!!!
 * NO SIGN               !!!!!!!!!!!!!
 *
 */
char *_ftoa(double f, int digits) {
    static char b[31];
    static char const digit[] = "0123456789";
    char* p = b;
    uint32_t i;
    double ff=f;

    int d,j;
    d=digits;
    while (d) {
        f*=10.0;
        d--;
    }

    i=(uint32_t)f;

    p=b+28;
    j=0;
    *p = 0;
    *(p+1)=0;



    do { //Move back, inserting digits as u go
        //TaskYield(0);
        if (j == digits) {
            p--;
            *p=',';
        }
        p--;
        *p = digit[i % 10ll];
        i = i/10ll;
        j++;
    } while(i);

    if (ff<1) {
        p--;
        *p = ',';
        p--;
        *p = '0';
    }


    return p; // return result as a pointer to string
}





//
//class mySerial
//{
//  private:
//    Stream *mystream;
//
//  public:
void mySerial::setSerial(Stream *streamObject) {
    mystream=streamObject;
}

// ------ Only these 2 must be redirected !!! ----
void mySerial::write( byte b) {
    mystream->write(b);
}

void mySerial::toSer( char c) {

#ifdef _ARDUINO
    // wait until Transmitter empty
    while ( !( UCSR0A & (1<<UDRE0)) ) {
        yield();
    }
    // send one byte
    UDR0 = (uint8_t)c;
#else
    Serial.write(c);
#endif


}

void mySerial::write( char c) {
    //mystream->write(c);
    OutBuf[SerHead++]=c;
    if (SerHead==SER_BUF_MAX) SerHead=0;
}
//------------------------------------------------

void mySerial::println() {
    write('\n');
}

void mySerial::print(char *str) {
    char *pt;
    pt=str;
    while(*pt) {
        write(*pt++);
        //TaskYield(10);
    }
}

void mySerial::println(char *str) {
    print(str);
    println();
}



void mySerial::print(unsigned int i) {
    char *pt;
    pt=_itoa(i);
    print(pt);
}

void mySerial::println(unsigned int i) {
    print(i);
    println();
}

void mySerial::print(uint8_t i) {
    char buf[20];
    itoa(i, buf, 10);
    print(buf);
}

void mySerial::print(uint8_t i, uint8_t n) {
    char buf[20];
    itoa(i, buf, n);
    print(buf);
}

void mySerial::print(unsigned int i, uint8_t n) {
    char buf[20];
    itoa(i, buf, n);
    print(buf);
}

void mySerial::println(unsigned int i, int n) {
    print(i,n);
    println();
}

void mySerial::println(uint8_t i) {
    print(i);
    println();
}

void mySerial::print(int i) {
    char *pt;
    pt=_itoa(i);
    print(pt);
}

void mySerial::println(int i) {
    print(i);
    println();
}


void mySerial::print(unsigned long i) {
    char *pt;
    pt=_ltoa(i);
    print(pt);
}

void mySerial::println(unsigned long i) {
    print(i);
    println();
}


void mySerial::print(long i) {
    char *pt;
    pt=_ltoa(i);
    print(pt);
}

void mySerial::println(long i) {
    print(i);
    println();
}


void mySerial::print(uint64_t i) {
    char *pt;
    pt=_ltoa(i);
    print(pt);
}

void mySerial::println(uint64_t i) {
    print(i);
    println();
}

void mySerial::print(float i) {
    print(_ftoa(i,4));
}

void mySerial::println(float i) {
    print(i);
    println();
}

//    void mySerial::print(float i, int digits) {
//      print(_ftoa(i,digits));
//    }
//
//    void mySerial::println(float i, int digits) {
//      print(i, digits);
//      println();
//    }

char mySerial::read() {
    return mystream->read();
}

bool mySerial::available() {
    return mystream->available();
}

void mySerial::flush() {
    mystream->flush();
}


// to do:        more types: float, double
//               even custom types are possible !



//}; // end class




extern mySerial MySer;




void MySer_Task(void *) {
  
    //if (SerHead == SerTail) return;  // nothing to do

#ifdef _COOPOS_  
    taskBegin();
    while (1) {
        taskDelay(100);
#endif

#ifdef _RTOS_  
    while (1) {
    
        vTaskDelay(1);
#endif

        extern uint32_t Switches;
        Switches++;
#ifdef _COOPOS_
        GPIO_PIN_SET(GPIOD,4);
        if (SerHead != SerTail) {
#endif


#ifdef _RTOS_  
        GPIO_PIN_SET(GPIOD,4);
        for (int i=0; i<3; i++)   // 3 characters burst = 3000/s
        if (SerHead != SerTail) {
#endif


// For output via Interrupt with RX_SER_OUT
#ifdef RX_SER_OUT                             // Buffered Serial output at RX via interrupt
            while (Ser_Ready == false) {
                taskDelay(10);
            }
            //Serial.write(OutBuf[SerTail]); // For Test only
            Ser_Byte=OutBuf[SerTail++];
            Ser_Ready=false;
#else
            MySer.toSer(OutBuf[SerTail++]);    // Buffered normal Serial output
#endif


            if (SerTail == SER_BUF_MAX) SerTail = 0;
            if (SerTail == SerHead) {
                SerTail = 0;
                SerHead=0;
            }
#ifdef _RTOS_
            vTaskDelay(1);
#endif

        } //  if/while SerHead != SerTail
        GPIO_PIN_RESET(GPIOD,4);
    }  // while

#ifdef _COOPOS_
    taskEnd();
#endif

}





//
//
//
//void setup() {
//  Serial.begin(115200);
//  delay(2000);
//  for (int i = 0; i < 20; i++) {
//    MySerial.print ("Okay it's hello world time.\n");
//  }
//}
//
//
//
//
//void loop() {
//  MySer_Task() ;
//}


#endif // _COOPOS_
