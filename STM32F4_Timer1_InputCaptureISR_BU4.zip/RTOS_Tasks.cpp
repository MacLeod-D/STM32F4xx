/*
========================================================================
  STM32_F4_Timer1_InputCaptureISR

  (C) 2020 Helmut Weber

========================================================================
*/

#pragma GCC optimize ("O3")

#include <Arduino.h>
#include "Defines.h"
#include "Config.h"
#include "HardwareTimer.h"
#include "DAC.h"


#ifdef _RTOS_

#include "RTOS_Tasks.h"


#ifdef _MYSER_
#include "MySerial.h"
extern mySerial MySer;
#else 
#define MySer Serial
#endif


extern uint32_t Switches;

char buf[2000];



//template<class T> inline Print &operator <<(Print &stream, T arg) {
//    stream.print(arg);
//    return stream;
//}


//uint32_t MaxTask1;
//
//void vTask1(void *pvParameters) {                             // show task switches LA
//uint32_t m, start_;
//int32_t diff;
//    pinMode(PD7,OUTPUT);
//    //start_=Timer1.getCompare(1); //micros();
//    start_=(uint32_t)micros();
//    //start_=TIM1->CCR1;
////    for (;;) {
////        GPIO_PIN_SET(GPIOD,7);
////        Switches++;
////        start_=m;
////        taskYIELD();
////        GPIO_PIN_RESET(GPIOD,7);
////        //m=Timer1.getCompare(1); //micros();
////        //m=micros();
////        m=TIM1->CCR1;
////        diff=m-start_;
////        
////        if (diff > MaxTask1) MaxTask1=diff;
////    }
//
//
//    for (;;) {
//        //m=TIM1->CCR1;
//        m=(uint32_t)micros();
//        taskYIELD();
//
//        noInterrupts();
//        GPIO_PIN_SET(GPIOD,7);
//        Switches++;
//        //start_= TIM1->CCR1;
//        start_ = (uint32_t)micros();
//        diff = start_ - m;
//        if (diff<0) diff=-diff;
//        if ((uint32_t)diff > MaxTask1) MaxTask1=(uint32_t)diff;
//        GPIO_PIN_RESET(GPIOD,7);
//        interrupts();
//    }
//}



uint64_t MaxTask1_=0;
uint64_t m_=0 , start_;
uint64_t diff_;
volatile bool T2InOutput=true;

void vTask1(void *pvParameters) {                             // show task switches LA
   
    //taskBegin();

    while(1) {
            taskYIELD();
            //noInterrupts();
            GPIO_PIN_SET(GPIOD,7);
            Switches++;

            
            if (m_ == 0)  m_ = micros();  
            else m_=start_;
    
            start_ = micros();
            //diff_ = start_ - m_;   
           
            if (!T2InOutput) {   
              diff_ = start_ - m_;  
              if (diff_ > MaxTask1_) MaxTask1_ = diff_; 
            }
            
            
            GPIO_PIN_RESET(GPIOD,7);
            //interrupts();

    }


    
    //taskEnd();
}



extern uint32_t volatile DA_Conv;

void vTask2(void *pvParameters) {                             // serial out
    uint32_t da_conv;
    uint32_t start1, start2, dif, delta;

    for (;;) {
        delta=millis();
#ifndef _TIMER1_ISR_
        //extern volatile uint32_t diff;
        //Timer1.setMode(1, TIMER_INPUT_CAPTURE_RISING, PA6);  // TIM1_CH1: PA6 (datasheet)
        //start1 = Timer1.getCompare(1);
        start1= TIM1->CCR1;
        do {
            //Wait for next rising edge
            //start2 = Timer1.getCompare(1);
            start2= TIM1->CCR1;                                  // Compare Count Register DIRECT for speed, not over HAL !
        } while(start2 == start1);
        if (start2<start1) {                                       // overflow ?
            dif= UINT32_MAX - start1 + start2+1;
        } else dif= start2-start1;
#else
        extern volatile uint32_t diff;
        dif=diff;
#endif
        // MySer.println(diff);
        //MySer.println(Micros());
        //MySer.print("  ");

        //Serial << diff << endl;



        MySer.print(" Diff:");
        vTaskDelay(1);
        MySer.println(dif);

        //vTaskDelay(1);
        //Serial << (" (RTOS) ");
        MySer.print(" (RTOS) ");
#ifdef _DAC_OS_
        Serial << " (DAC: OS) ";
        vTaskDelay(1);
#endif
#ifdef _TIMER1_ISR_
        MySer.print(" (DAC: T-ISR) ");
        vTaskDelay(1);
#endif



        //vTaskDelay(1);
        //Serial << diff;
        //if (diff>0) MySer.print( ( ( (float) 1/(float)diff * (float) 168000000/ (float)1000000 ),6));

if (dif>0) MySer.print(  (float) 168/(float)dif);
        
        //vTaskDelay(1);
        //Serial << (" MHz   DA-Conv ");
        MySer.print (" MHz   DA-Conv ");
        vTaskDelay(1);
        //Serial << da_conv << endl;
        MySer.println(da_conv);
        vTaskDelay(1);
        
        MySer.print(" T-Switches:");
        vTaskDelay(1);
        //Serial << Switches << endl;  Switches=0;
        MySer.println(Switches);
        vTaskDelay(1);
        Switches=0;
        MySer.print(" Delta Task1 us: ");
        vTaskDelay(1);;
        //MySer.println(start_-m_);
        //taskSwitch();
        //MySer.println((float)diff_/(float)168);
        MySer.println(diff_);
        
        //if (diff_ > MaxTask1_) MaxTask1_ = diff_;
        vTaskDelay(1);
        
        MySer.print(" Max   Task1 us: ");
        vTaskDelay(1);
        MySer.println (MaxTask1_);
       
        
        vTaskDelay(1);
        
        
        
#ifdef _SHOW_TASKLIST_

        // configUSE_TRACE_FACILITY and configUSE_STATS_FORMATTING_FUNCTIONS must be defined as 1
        /* For v9.0.0 it should be enough to enable configurations as you did. But v10.0.0 there is also dependency on
           configSUPPORT_DYNAM
           IC_ALLOCATION: if in project's FreeRTOSConfig.h it's defined to something other than default ("1")
           - vTaskList will be excluded. This dependency, however, is neither mentioned in include header file task.h
           nor in online documentation
        */

        vTaskList(buf);
        vTaskDelay(1);
        MySer.println("********************************************");
        vTaskDelay(1);
        MySer.println("Task\t\tState\tPrio\tStack\tNum");
        vTaskDelay(1);
        MySer.println("********************************************");
        vTaskDelay(1);
        MySer.print(buf);
        vTaskDelay(1);
        MySer.println("********************************************");
#endif
        DA_Conv=0;


        // ----
        //m_=0;
        T2InOutput=false;
        // ----
        
        vTaskDelay(1000 -  (millis()-delta) +1 );

#ifndef _MEASURE_TSWITCH_IN_OUTPUT_
        T2InOutput=true;
        m_=0;
 #endif
 
        da_conv=DA_Conv;
    }
}


void vTask3(void *pvParameters) {                             // blink
    static uint32_t out=0;
    pinMode(PA7,OUTPUT);
    for (;;) {
        GPIO_PIN_SET(GPIOA,7);

        Switches++;
        vTaskDelay(500);
        GPIO_PIN_RESET(GPIOA,7);
        Switches++;

        //out+=10;
        //DAC_Out((uint8_t)out & 0xff);

        vTaskDelay(500);
    }

}

#ifdef _DAC_OS_

void vTask4(void *pvParameters) {                             // DAC
    static uint32_t val=0;
    GPIO_Config();
    DAC1_Config();
    DAC1_Start();
    GPIO_HISPEED_SET(GPIOA,4);                                // PA4: output analog
#ifdef _DAC_8_
    for (;;) {
        DA_Conv++;
        DAC1_Out8((uint8_t)val & 0xff);
        val++;
        if (val>255) val=0;
        vTaskDelay(1);                                        // increment 100/255 per second  (for LA)
        //vTaskDelay(100);                                    // increment 10/255 per second  (for volt meter)
        Switches++;
    }
#endif

#ifdef _DAC_12_
    for (;;) {

        DAC1_Out12((uint16_t)val & 0xfff);
        val+=8;
        if (val>4095) val=0;
        vTaskDelay(1);                                      // increment 100/255 per second  (for LA)
        //vTaskDelay(100);                                     // increment 10/255 per second  (for volt meter)
        Switches++;
    }

#endif
}
#endif // _DAC_OS_


#endif // _RTOS_
