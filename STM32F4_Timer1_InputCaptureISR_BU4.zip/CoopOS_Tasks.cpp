/*
========================================================================
  STM32_F4_Timer1_InputCaptureISR

  (C) 2020 Helmut Weber

========================================================================
*/

#pragma GCC optimize ("O3")

#include <Arduino.h>
#include "Config.h"
//#include "stm34f1xx.h



#ifdef _COOPOS_

#include "CoopOS_Tasks.h"
#include "DAC.h"
#include "HardwareTimer.h"

#ifdef _MYSER_
#include "MySerial.h"
extern mySerial MySer;
#else
#define MySer Serial
#endif



extern uint32_t Switches;


char buf[2000];


uint64_t MaxTask1_=0;
uint64_t m_=0 , start_;
uint64_t diff_;

bool T2InOutput=true;


void vTask1(void *pvParameters) {                             // show task switches LA
  
    taskBegin();

    while(1) {
            taskDelay(20);
        
            //noInterrupts();
            GPIO_PIN_SET(GPIOD,7);
            Switches++;
            
            if (m_ == 0)  m_ = micros();  
            else m_=start_;
    
            start_ = micros();

            if (!T2InOutput) {   
              diff_ = start_ - m_;  
              if (diff_ > MaxTask1_) MaxTask1_ = diff_; 
            }
            
            
            GPIO_PIN_RESET(GPIOD,7);
            //interrupts();

    } //  while    
    taskEnd();
}



extern uint32_t volatile DA_Conv;
#ifdef _MYSER_
extern mySerial MySer;
#endif


void vTask2(void *pvParameters ) {                             // serial out
    static uint32_t da_conv;
    static uint32_t delta, start1, start2, dif;
    static float f;
    uint32_t ff;


    taskBegin();

    while(1) {
        
        delta=micros();
#ifndef _TIMER1_ISR_
        //extern volatile uint32_t diff;
        //Timer1.setMode(1, TIMER_INPUT_CAPTURE_RISING, PA6);  // TIM1_CH1: PA6 (datasheet)
        //start1 = Timer1.getCompare(1);
        start1= TIM1->CCR1;
        do {
            //Wait for next rising edge
            //start2 = Timer1.getCompare(1);
            start2= TIM1->CCR1;                                  // Compare Count Register DIRECT for speed, not over HAL !
        } while(start2 == start1);

        if (start2<start1) {                                       // overflow ?
            dif= UINT32_MAX - start1 + start2+1;
        } else dif= start2-start1;
#else
        extern volatile uint32_t diff;
        dif=diff;
#endif

        MySer.print(" Diff:");
        taskSwitch();
        MySer.println(dif);

        taskSwitch();
        MySer.print( " (CoopOs) ");
        taskSwitch();
#ifdef _DAC_OS_
        MySer.print("(DAC: OS) ");
        taskSwitch();
#endif
#ifdef _TIMER1_ISR_
        MySer.print("(DAC: T-ISR) ");
        taskSwitch();
#endif
        MySer.print(" T3: ");
        taskSwitch();
        f=(float)168 / (float)dif;
        //ff=168 / dif;
        taskSwitch();
        MySer.print(f);
        taskSwitch();
        MySer.print(" MHz   DA-Conv ");
        taskSwitch();
        MySer.println(da_conv);
        //MySer.print(endl); //DA_Conv=0;
        //MySer.println(isr);
        taskSwitch();
        MySer.print(" T-Switches ");
        taskSwitch();
        MySer.println(Switches);
        Switches=0;
        taskSwitch();

        MySer.print(" Delta Task1 us: ");
        taskSwitch();
        MySer.println(diff_);

        //if (diff_>MaxTask1_) MaxTask1_=diff_;
        
        taskSwitch();
        
        MySer.print(" Max   Task1 us: ");
        taskSwitch();  
        MySer.println (MaxTask1_);
        taskSwitch();
        
        
#ifdef _SHOW_TASKLIST_
        TaskList(buf);
        MySer.println("\n---");
        taskSwitch();
        MySer.println("Task\t\t\tState\tPrio\tDelay\tW-Res\tWSig\tLast-T\t\tTimes called");
        taskSwitch();
        MySer.print(buf);
        taskSwitch();
#endif       
        
        
        MySer.println("---");



        DA_Conv=0; 

        // -------
        //m_ = 0;     // with m_=0 measuring during serial output is disabled
        T2InOutput=false;
        // ------
        
        
#ifndef _SHOW_TASKLIST_
        // without _SHOW_TASKLIST_
        taskDelay(1000000-(micros()-delta)+31);// experimental tuning for repeating every ms ...
#else
        // with _SHOW_TASKLIST_
        taskDelay(1000000-(micros()-delta)+10000);// experimental tuning for repeating every ms ...
#endif

#ifndef _MEASURE_TSWITCH_IN_OUTPUT_
        T2InOutput=true;
        m_=0;
#endif
 
        
        da_conv=DA_Conv;                        // .. to show, how deterministic CoopOS can be
    }
    
    taskEnd();
}


void vTask3(void *pvParameters) {                             // blink
    static uint32_t out=0;
    taskBegin();
    pinMode(PA7,OUTPUT);
    while(1) {
        GPIO_PIN_SET(GPIOA,7);

        Switches++;
        taskDelay(50000);
        GPIO_PIN_RESET(GPIOA,7);
        Switches++;
        taskDelay(50000);
    }
    taskEnd();
}




#ifdef _DAC_OS_
void vTask4(void *pvParameters) {                             // DAC
    static uint32_t val=0;
    taskBegin();
    GPIO_Config();
    DAC1_Config();
    DAC1_Start();
    GPIO_HISPEED_SET(GPIOA,4);                                // PA4: output analog

    while(1) {


#ifdef _DAC_8_

        DA_Conv++;
        DAC1_Out8((uint8_t)val & 0xff);
        val++;
        if (val>255) val=0;
        //taskDelay(9);                                      // increment 100/255 per second  (for LA)
        //vTaskDelay(100000);                                     // increment 10/255 per second  (for volt meter)

#endif

#ifdef _DAC_12_
        DAC1_Out12((uint16_t)val & 0xfff);
        val+=8;
        if (val>4095) val=0;
        //taskDelay(10);                                      // increment 100/255 per second  (for LA)
        //taskDelay(100000);                                     // increment 10/255 per second  (for volt meter)

#endif
        Switches++;
        taskDelay(9);
    } // while

    taskEnd();
}
#endif // _DAC_OS_





#endif // _COOPOS_
