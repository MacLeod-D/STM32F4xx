/*
========================================================================
  STM32_F4_Timer1_InputCaptureISR

  (C) 2020 Helmut Weber

========================================================================
*/


#ifndef COOPOS_Defines_H
#define COOPOS_DEFINES_H

#include <Arduino.h>
#include <stdint.h>

#include "Config.h"
#include "Defines.h"

#include "CoopOS.h"

extern uint32_t Resource[];

extern TCB *thisTask;
extern TCB Tasks[];
extern int32_t HiPrio;

// To manipulate task states, do delays and task switches

#define taskBegin()\
  static int _mark = 0;\
  switch (_mark) {\
  case 0:

#define taskEnd()    _mark=0;\
    return;  \
  }

extern uint32_t numTasks;


#define taskSwitch() _mark=__LINE__; return;  case __LINE__:


#define taskDelay(val)    _mark=__LINE__; thisTask->Delay =val; thisTask->Status=DELAYED; return; case __LINE__:

// kann auf vom ISR benutzt werden:
#define taskStop(id)      _mark=__LINE__; Tasks[id]Delay =0;    Task[id].Status=BLOCKED;

#define taskStopMe()      _mark=__LINE__; thisTask->Delay =0;   thisTask->Status=BLOCKED; return; case __LINE__:

//#define taskResume(id)    _mark=__LINE__; Tasks[id].Delay =0;   Tasks[id].Status=READY; return; case __LINE__:
#define taskResume(id)    Tasks[id].Delay =0;   Tasks[id].Status=READY;

#define taskWaitSig(sig)  _mark=__LINE__; thisTask->Delay =0;   thisTask->Signal=sig; thisTask->Status=WAITSIG; return; case __LINE__:

// kann auch vom ISR benutzt werden:
#define taskSetSig(sig)  \
for (int ix=0; ix<numTasks; ix++) {\
struct tcb *tp;\
  tp=&Tasks[ix];\
  if (tp->Signal==sig) {\
    tp->Signal=0; tp->Status=READY;\
    if (HiPrio==-1)  HiPrio=ix; /* first met get high priority */\
  }\
}


#define taskWaitRes(res)  _mark=__LINE__; \
/*Serial.print("Wait RES "); Serial.print(res); Serial.print(".. Task " ); Serial.println(thisTask->ID);*/\
/*  Wenn die resource frei ist, dann sofort weiter */\
if (Resource[res]==0) {\
  Resource[res]=thisTask->ID;\
  /*Serial.print("RES is free, Resource "); Serial.println(res);*/\
}\
/*  Wenn die resource NICHTfrei ist: gehört sie mir schon ? */\
else {\
  if (Resource[res]==thisTask->ID) {\
    /*Serial.print("RES is mine, Task "); Serial.println(thisTask->ID);*/\
  }\
  /*  ist fremd besetzt ! Task muss warten */\
  else {\
    /*Serial.print("RES wait, Task "); Serial.println(thisTask->ID);*/\
    thisTask->Resource=res;\
    thisTask->Status=WAITRES; \
    taskSwitch();\
  }\
}


// Only Owner is allowed to use this (not ISR)

#define taskFreeRes(res)  \
/*Serial.print(thisTask->ID); Serial.print("  frees ... "); Serial.println(Resource[res]); */\
if (Resource[res] == thisTask->ID) {\
  /*Serial.println("FREE - RES is mine");*/\
  Resource[res] = 0;\
  for (int ix=0; ix<numTasks; ix++) {\
  struct tcb *tp;\
    tp=&Tasks[ix];\
    if (tp->Status == WAITRES) {\
      if (tp->Resource==res) {\
        /*Serial.print(thisTask->ID); Serial.print(" enables "); Serial.println(tp->ID);*/\
        tp->Resource=0; tp->Status=READY;\
        Resource[res]=tp->ID;\
        break;\
      }\
    }\
  }\
}


#define irqTaskSetBlocked(id) cli(); IrqTasks[id].Status=IBLOCKED; sei();

#define irqTaskSetReady(id) cli(); IrqTasks[id].Status=IREADY; sei();

//#define BREAKPOINT STOP=true; Debug.current = thisTask->ID; Debug.start=_nanos(); taskSetSig(SIG_DEB);
#define BREAKPOINT STOP=true; Debug.current = thisTask->ID; Debug.start=Micros(); taskSetSig(SIG_DEB);

#endif
