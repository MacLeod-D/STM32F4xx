/*
========================================================================
  STM32_F4_Timer1_InputCaptureISR

  (C) 2020 Helmut Weber

========================================================================
*/

#ifndef MYSERIAL_H
#define MYSERIAL_H


extern void MySer_Task(void *);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <itoa.h>
#include <Arduino.h>
#include "CoopOS_Defines.h"
#include "Config.h"

//template<class T> inline Print &operator <<(Print &stream, T arg) {
//    stream.print(arg);
//    return stream;
//}


// MySerial:
// Redirect Serial to any destination

extern volatile int SerHead;
extern volatile int SerTail;

//#define SER_BUF_MAX 500  // Config.h
extern char OutBuf[];








/**
 * \brief
 * "_itoa"<br>
 * This is the selfmade conversion from unsigned int to ascii-string<br>
 * digits are the number of digits behind the"."
 */
char *_itoa(unsigned int l);

/**
 * \brief
 * "_ltoa"<br>
 * This is the selfmade conversion from unsigned long to ascii-string<br>
 * digits are the number of digits behind the"."
 */
char *_ltoa(unsigned long l);


/**
 * \brief
 * "_lltoa"<br>
 * This is the selfmade conversion from unsigned long to ascii-string<br>
 * digits are the number of digits behind the"."
 */
char *_lltoa(unsigned long l);

/**
 * \brief
 * "ftoa"<br>
 * This is the selfmade conversion from float to ascii-string<br>
 * digits are the number of digits behind the"."
 *
 * f MUST be greater 0.1 !!!!!!!!!!!!!
 * NO SIGN               !!!!!!!!!!!!!
 *
 */
char *_ftoa(double f, int digits);





class mySerial {
private:
    Stream *mystream;

public:
    void setSerial(Stream *streamObject);

// ------ Only these 2 must be redirected !!! ----
    void write( byte b);

    void toSer( char c);

    void write( char c);
//------------------------------------------------

    void println();

    void print(char *str);

    void println(char *str);

    void print(unsigned int i);

    void println(unsigned int i);

    void print(uint8_t i);

    void print(uint8_t i, uint8_t n);

    void print(unsigned int i, uint8_t n);

    void println(unsigned int i, int n);

    void println(uint8_t i);

    void print(int i);

    void println(int i);

    void print(unsigned long i);

    void println(unsigned long i);

    void print(long i);

    void println(long i);

    void print(uint64_t i);

    void println(uint64_t i);

    void print(float i);

    void println(float i);

//    void print(float i, int digits);
//
//    void println(float i, int digits);

    char read();

    bool available();

    void flush();


// to do:        more types: float, double
//               even custom types are possible !



}; // end class




extern mySerial MySer;


void MySer_Task(void *);

#endif // MYSERIAL_H
