/*
========================================================================
  STM32_F4_Timer1_InputCaptureISR

  (C) 2020 Helmut Weber

========================================================================
*/


#include <Arduino.h>
#include <stdint.h>

#include "DAC.h"

#ifdef _STM32F4_      // no DAC for STM32F1 !

void GPIO_Config() {
    // Enable GPIOA clock
    ///RCC->AHB1ENR |= 1UL<<0;            // RCC AHB1 peripheral clock register (RCC_AHB1ENR), Bit0: GPIO-AEN
    RCC->AHB1ENR |= 1UL<<0;               // RCC AHB1 peripheral clock register (RCC_AHB1ENR), Bit0: GPIO-AEN

    // Set PA4 to analog output
    GPIOA->MODER |= 3UL<<(4*2);
}


void DAC1_Config() {
    // Enable DAC interface clock
    RCC->APB1ENR |= 1UL<<29;              // RCC->APB1ENR: Bit 29 DACEN: DAC interface clock enable

    // Clear other non used bits
    DAC->CR &= ~(0x3fffUL << 16);         // DAC channel2 - all 0 (not reserved)
    DAC->CR &= ~(0x1fffUL << 1);          // DAC channel1 - all 0 (not reserved), but bit0(=DAC channel1 is 1)
    ///==DAC->CR = 1;                        // DAC channel1 enabled

}

void DAC1_Start() {
    // DAC channel1 enabled
    DAC->CR |= 1;
}

void DAC2_Start() {
    // DAC channel1 enabled
    DAC->CR |= 16;
}

//void DAC1_Out8( uint32_t val) {
//    DAC->DHR8R1 =val;
//}
//
//void DAC1_Out12( uint32_t val) {
//    DAC->DHR12R1 =val;
//}

#endif // STM32F4
