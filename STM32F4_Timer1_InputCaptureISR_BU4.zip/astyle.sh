astyle --style=allman --style=attach *

