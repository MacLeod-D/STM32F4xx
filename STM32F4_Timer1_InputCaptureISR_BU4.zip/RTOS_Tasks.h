/*
========================================================================
  STM32_F4_Timer1_InputCaptureISR

  (C) 2020 Helmut Weber

========================================================================
*/

#include "Defines.h"
#include "Config.h"


#ifdef _RTOS_

#ifndef _RTOS_H
#define RTOS_H

//#include <Arduino_FreeRTOS.h>


void vTask1(void *pvParameters);

void vTask2(void *pvParameters);

void vTask3(void *pvParameters);

#ifdef _DAC_OS_
void vTask4(void *pvParameters);
#endif

#endif
#endif // _RTOS_
