/*
========================================================================
  STM32_F4_Timer1_InputCaptureISR

  (C) 2020 Helmut Weber

========================================================================
*/


#include <Arduino.h>

#include "Defines.h"
#include "Config.h"



#ifdef _COOPOS_

#ifndef _COOPOS_TASKS_H
#define COOPOS_TASKS_H

#include "HardwareTimer.h"
#include "CoopOS.h"
//#include "CoopOS_Defines.h"
#include "MySerial.h"



//template<class T> inline Print &operator <<(Print &stream, T arg) {
//    stream.print(arg);
//    return stream;
//}
//#define endl "\n"


void vTask1(void *pvParameters);

void vTask2(void *pvParameters );

void vTask3(void *pvParameters);

#ifdef _DAC_OS_
void vTask4(void *pvParameters);
#endif // _DAC_OS_






#endif // _COOPOS_TASKS_H
#endif // _COOPOS_
