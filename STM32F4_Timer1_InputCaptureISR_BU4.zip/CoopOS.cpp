/*
========================================================================
  STM32_F4_Timer1_InputCaptureISR

  (C) 2020 Helmut Weber

========================================================================
*/


#include <Arduino.h>
#include <stdint.h>

#include "Config.h"
#include "Defines.h"

#include "CoopOS.h"
#include "CoopOS_Defines.h"


//
////
////template<class T> inline Print &operator <<(Print &stream, T arg) {
////    stream.print(arg);
////    return stream;
////}

volatile uint32_t clock_cycles_counter;
volatile uint32_t idle_clock_cycles_counter;


TCB Tasks[MAXTASKS];
uint32_t numTasks=0;

int32_t HiPrio=-1;
TCB *thisTask;

char *stateTxt[] = { (char *)"R",   (char *)"D",     (char *)"B",    (char *)"S",     (char *)"R" };



/*
 TaskInit is used to initialize the TCBs for the Tasks.<br>

 @param[in]    name             The Text-Name of the Task - it is shown in lists
 @param[in]    f                The Source-Name of the function which acts as Task
 @param[in]    priority         Reserved - not used now
 @param[in]    stat             The state to start with for this Task   (READY / DELAYED / BLOCKED)
 @param[in]    del              The Delay-time fot this task before starting
 @param[in]    param            A pointer to a parameter. it is up to the user to build and read parameters
 @return       ID               Returns the ID of the Tasks which can be used as handle: for instance for taskResume(ID)


 ID  - This is a 8 bit number which is created automatically and identifies the Task by ID;


 \brief Initialises TCBs (TaskControlBlocks) which are the Tasks
*/





int TaskInit(char *name, void (*f)(void *), uint8_t priority, uint8_t stat, uint32_t del, void *param) {
    Serial.print("TaskInit #  "); Serial.print( numTasks);  Serial.print( "/");  Serial.print( MAXTASKS);  Serial.print( "  "); Serial.println(name);
    if (numTasks >= MAXTASKS) {
        //assert(false)
        //sprintf(OutBf,"=== ERR: MAXTASKS ===\n");
        //MsgFlag=1;
        Serial.print("TaskInit: === ERR: MAXTASKS ===\n");
        while (1);
        return -1;                                // Fehler
    }

    Tasks[numTasks].ID =          numTasks;
    Tasks[numTasks].Name =        name;
    Tasks[numTasks].Func =        f;
    Tasks[numTasks].Priority =    priority;     // reserved
    Tasks[numTasks].Status =       stat;
    Tasks[numTasks].Delay =       del;
    Tasks[numTasks].Param =       param;

    if (Tasks[numTasks].Delay) Tasks[numTasks].Status =  DELAYED;

    //sprintf(OutBf,"=== TaskInit ID: %d <%s> ===\n", numTasks,name);
    //MsgFlag=1;


    //Serial.print(F(" TaskInit:           "));
    //Serial.print(name);
    //Serial.print(F("\t\t# "));
    //Serial.println(numTasks);

    numTasks++;
    return (numTasks - 1);
}





//// handle diagnostic informations given by assertion and abort program execution:
//void __assert(const char *__func, const char *__file, int __lineno, const char *__sexp) {
//    // transmit diagnostic informations through serial link.
//    Serial.println(__func);
//    Serial.println(__file);
//    Serial.println(__lineno, DEC);
//    Serial.println(__sexp);
//    Serial.flush();
//    // abort program execution.
//    abort();
//}




/*
  ------
  class CoopOS::Scheduler()
  ------

  \anchor Scheduler

   \details The Scheduler is the central function to call Tasks<br>
  At first it looks for <b>HiPrio</b> which is set bý a Signal - and call such a Task.<br>
  Then it tests (in a FOR-Loop), which Tasks should change the State from DELAYED to READY.<br>
  READY Tasks are called.<br>
  If INTERNAL_PRIO is defined (Config.h) then the Scheduler returns - and starts the next time again with<br>
  the first inited Task (TaskInit()) . <br>
  If INTERNAL_PRIO is <b>NOT</b> defined (Config.h) then the Scheduler tests all existing Tasks (no priority)<br>

  If a Task is called, <b>LastCalled</b> is set.<br>

  If you uncomment the three lines after <b>if (thisTask->State == READY) {</b> the Scheduler will generate a number of peaks to identify the<br>
  Tasks which will be called. With a Logic Analyzer you will be able to see, wich Tasks is called.
*/


volatile uint32_t SchedCount;


uint64_t        m;
uint8_t i_start = 0;
uint8_t DoneATask = 0;
int ii;








void Scheduler() {


Start:

    //PULSE_OFF(SCHED_PIN);

    //seconds= (Micros()-startAllTime) / (uint64_t)1000000;
//        _seconds=(uint64_t)Micros();
//        _seconds-=startAllTime;
//        _seconds/=1000000ll;

    // HiPrio=-1;  // to test the influence of high priorized Signals

    if (HiPrio>=0) {
        i_start = HiPrio;
        HiPrio = -1;
    } else i_start=0;

    //i_start=0;

    m=micros();

    for (int ii = i_start; ii < numTasks; ii++) {
        //for (ii = 0; ii < numTasks; ii++) {

        SchedCount++;

        thisTask = &Tasks[ii];
        if (thisTask->Status == DELAYED) {
            if ((m - thisTask->LastCalled) >= thisTask->Delay) {
                thisTask->Status = READY;
            }

        }
        if (HiPrio>=0) goto Start;


        if (thisTask->Status == READY) {

#ifdef SHOW_TASKNUM
            for (int i = 0; i < (thisTask->ID +1); i++ ) {
                //noInterrupts();
                SetPB13();
                ClearPB13();
                //interrupts();
            }
#endif

            // STM32F1
            // SetPB13();

            //extern void HC74595(uint8_t);
            //HC74595((uint8_t)(SchedCount & 0xff));

            thisTask->Func(thisTask->Param);                  // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<< call the Task
            // STM32F1
            //ClearPB13();

            thisTask->LastCalled = m;
            thisTask->Count++;
            DoneATask = 1;





            if (HiPrio>=0) goto Start;
#ifdef INTERNAL_PRIO
            // This means: not all READY tasks are call in one Scheduler start, but the first READY in the list.
            // Then the Scheduler is called again and searches again from task 0 - the first initialized.
            return;
#endif
        }
    } // for
    i_start=0;
    HiPrio=-1;

    if (!DoneATask) goto Start;
} // Scheduler
// -------------------------------------------------




void TaskList(char *bf) {
    TCB *t;
    char *pt;
    int adv;
    pt=bf;
    for (int i=0; i<numTasks; i++) {
        t=&Tasks[i];
        adv=sprintf(pt, "%s\t\t%s\t%u\t%lu\t%u\t%u\t%lu\t%u\n", t->Name, stateTxt[t->Status], t->ID, (uint32_t)t->Delay, t->Resource, t->Signal, (uint32_t)t->LastCalled, t->Count);
        t->Count=0;
        pt+=adv;
    }
}

//---------------------------------------------------------------------------------
