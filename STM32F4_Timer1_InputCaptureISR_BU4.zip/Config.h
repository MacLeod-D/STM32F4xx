
/*
========================================================================
  STM32_FirstTryCoopOS2

  (C) 2018-2029 Helmut Weber

========================================================================
*/

#ifndef CONFIG_H
#define CONFIG_H

// select one processor:
// ----------------------------------------

#define _STM32F4_
//#define _STM32F1_  // not useful here because of missing DAC - just an example

// Rules

    #ifdef _STM32F4_
    #include "stm32f407xx.h"
    #include "system_stm32f4xx.h"
    #include "stm32f4xx_hal_gpio.h"
    #include "stm32f4xx_hal_dac.h"
    // to find more:   find  ~/Arduino/hardware/STM32GENERIC  -iname "stm32f4*"
    #endif
    
    #ifdef _STM32F4_
    #undef _STM32F1_
    #endif
    
    #ifdef _STM32F1_
    #undef _STM32F4_
    #include "stm32f1xx.h"
    #endif


/*
============================ This Program ==============================
*/




// select one or non OS (No OS ==Loop):
// ------------------------------------------------------

// use RTOS-Tasks
//#define _RTOS_

// use COOPOS-Tasks
#define _COOPOS_


// Rules:
    #ifdef _COOPOS_
      #undef _RTOS_
    #endif
    #ifdef _RTOS_
      #undef _COOPOS_
    #endif



// use serial buffered output and Task MySer_Task(). Only with OS !
#define _MYSER_

// Rules:
    #ifndef _RTOS_
      #ifndef _COOPOS_
        #undef _MYSER_
      #endif
    #endif


// measure TaskSwitch delay also in serial output:
//#define _MEASURE_TSWITCH_IN_OUTPUT_


// up to 2.000.000 Interrupts per second (without serial output):
#define _TIMER1_ISR_

 
// Enable, Disable Pulse Length measurement in ISR
//#define _TIMER1_COUNT_
// Rules:
    #ifdef _TIMER1_ISR_
      #undef _TIMER1_COUNT_ // ISR itself is counting
    #endif




    
// use DA-Conversion
#define _DAC_

// Rules:    
    #ifdef _DAC_            // select only one !
      //#define _DAC_OS_
      #define _DAC_ISR_
    #endif
    
    #ifdef _DAC_            // select only one !
      #define _DAC_8_
      //#define _DAC_12_
    #endif

    // OS defined, but _TIMER1_ISR_ is not:
    #ifdef _DAC_
      #if defined(_COOPOS_) || defined(_RTOS_)
        #ifndef _TIMER1_ISR_
           #define _DAC_OS_
        #else
          #undef _DAC_OS_
        #endif
      #endif
    #endif 
    
    // OS defined, AND _TIMER1_ISR_ :
    #ifdef _DAC_
      #if defined(_COOPOS_) || defined(_RTOS_)
        #ifdef _TIMER1_ISR_
           #undef _DAC_OS_
        #endif
      #endif
    #else
      #undef _DAC_OS_
      #undef _DAC_ISR_
    #endif 
    
    
    // make sure just one is selected
    #ifdef _DAC_OS_
      #undef _DAC_ISR_
    #endif
    
    #ifdef _DAC_ISR_
      #undef _DAC_OS_
    #endif
    
    #ifdef _DAC_8_
      #undef _DAC_12_
    #endif
    
    #ifdef _DAC_12_
      #undef _DAC_8_
    #endif
    
    //#define _DAC_BRUTEFORCE_
    #ifdef _DAC_BRUTEFORCE_
      #define _DAC_
      #define _DAC_OS_
      #define _DAC_8_
      #undef _COOPOS_
      #undef _RTOS_
      #undef _MYSER_
      #undef _TIMER1_ISR_
      #define _DAC_8_
    #endif

    #ifndef _DAC_
      #undef _DAC_OS_
      #undef _DAC_ISR_
    #endif



// compiler shows defines as warnings
#define  _SHOW_DEFINES_

/*
============================ End this Program ==========================
*/


//========================== CoopOS ====================================

#ifdef _COOPOS_

#include "CoopOS_Defines.h"
#include "CoopOS.h"
#include "CoopOS_Tasks.h"

/*
 * Maximum number of TCBs = Tasks
 */
#define MAXTASKS 10

/*
 * Enables the internal priority which means:
 * When the Scheduler called a task it returns,
 * instead of searching for more tasks in the list.
 * So the first tasks in the TaskInit-ed list have
 * the highest priority snd may suppress tasks wirh
 * lower priority !
 *
 * Otherwise ALL READY tasks are run with a Scheduler call.
 */
#define INTERNAL_PRIO

//#define _SHOW_TASKLIST_


#define SER_BUF_MAX 500

#endif // _COOPOS_

/*
============================ End CoopOS ================================
*/

//========================== RTOS ====================================

#ifdef _RTOS_
#include <Arduino_FreeRTOS.h> 
// to find more:   find  ~/Arduino/hardware/STM32GENERIC  -iname "*rtos*"

//#define _SHOW_TASKLIST_


#define SER_BUF_MAX 500

#endif // _RTOS_

/*
============================ End RTOS ================================
*/



#ifndef _COOPOS_
  #ifndef _RTOS_
    #undef _MYSER_
  #endif
#endif










/*
 * If disabled suppresses the Serial Output
 * Then controlling only wit scope/LS is possible
 * Much faster !
 */
#define SERIAL_OUT



/*
 * If enable and SERIAL_OUT disabled only TSignal received is printed
 * suppresses the Serial Output
 * Then controlling only wit scope/LS is possible
 * Much faster !
 */
#define SERIAL_OUT_RECONLY

#ifdef SERIAL_OUT
#define SERIAL_OUT_RECONLY
#endif

/*
 * If disabled suppresses the I2C access to the
 * PCF8591 AD/DA converter
 * Much faster !
 */
#define PCF_TASK


/*
 * If disabled suppresses the shift register
 * in Timer Interrupt
 */
#define HC_74595






/*
 * Enables the Timer Interrupt.
 * Time is set in   setup()
 */
#define TIMER_ON



/*
 * Enables External Interrupts at PB0
 * If PB0 is connectd to PB12 the External Inrerrupts
 * are done by Timer Inerrupts
 */
#define EXTERNAL_ON

/*
 * Enables External Interrupts at PB1
 * If PB1 is connectd to RotaryButton
 * Interrupts External2 are done
 */
#define EXTERNA2L_ON


/*
 * Disables interrupts during the (very short)
 * time Idle Pulses are generated.
 * They may not prolonged by interrupts
 */
#define IDLEPULSE_NOINTERRUPT



/*
 * This is a mighty debugging tool.
 *
 * Before the Scheduler calls a task in sends pulses at PB13 to identify the
 * tasks.
 * 1 pulse = 1. TaskInit()-ed Task
 * 2 pulse = 2. TaskInit()-ed Task
 *
 * It is time consuming, but it makes it easy to see when the different tasks
 * are running and how long time thea need.
 *
 */
//#define SHOW_TASKNUM

//===============================

#endif
