/*
========================================================================
  STM32_F4_Timer1_InputCaptureISR

  (C) 2020 Helmut Weber

========================================================================
*/


#ifndef DEFINES_H
#define DEFINES_H

#include "Config.h"



#ifdef _STM32F1_
#include "stm32f1xx.h"
#endif

#ifdef _STM32F4_
#define GPIO_PIN_SET(PORT,pin)          ((PORT)->BSRR = 1 << (uint32_t)pin)
#define GPIO_PIN_RESET(PORT,pin)        ((PORT)->BSRR = (1 << (uint32_t)pin) << 16)
#define GPIO_HISPEED_SET(port,pin)      (port)->OSPEEDR = (port)->OSPEEDR | (0b11 << (2*pin))
#endif

#include <stdint.h>






/*
 * Maximum number of TCBs = Tasks
 */
#define MAXTASKS 10



/*
 * If disabled suppresses the Serial Output
 * Then controlling only wit scope/LS is possible
 * Much faster !
 */
#define SERIAL_OUT



///*
// * If enable and SERIAL_OUT disabled only TSignal received is printed
// * suppresses the Serial Output
// * Then controlling only wit scope/LS is possible
// * Much faster !
// */
//#define SERIAL_OUT_RECONLY
//
//#ifdef SERIAL_OUT
//#define SERIAL_OUT_RECONLY
//#endif
//
///*
// * If disabled suppresses the I2C access to the
// * PCF8591 AD/DA converter
// * Much faster !
// */
//#define PCF_TASK
//
//
///*
// * If disabled suppresses the shift register
// * in Timer Interrupt
// */
//#define HC_74595
//
//
///*
// * Enables the internal priority which means:
// * When the Scheduler called a task it returns,
// * instead of searching for more tasks in the list.
// * So the first tasks in the TaskInit-ed list have
// * the highest priority snd may suppress tasks wirh
// * lower priority !
// *
// * Otherwise ALL READY tasks are run with a Scheduler call.
// */
//#define INTERNAL_PRIO
//
//
//
///*
// * Enables the Timer Interrupt.
// * Time is set in   ssetup()
// */
//#define TIMER_ON
//
//
//
///*
// * Enables External Interrupts at PB0
// * If PB0 is connectd to PB12 the External Inrerrupts
// * are done by Timer Inerrupts
// */
//#define EXTERNAL_ON
//
///*
// * Enables External Interrupts at PB1
// * If PB1 is connectd to RotaryButton
// * Interrupts External2 are done
// */
//#define EXTERNA2L_ON
//
//
///*
// * Disables interrupts during the (very short)
// * time Idle Pulses are generated.
// * They may not prolonged by interrupts
// */
//#define IDLEPULSE_NOINTERRUPT
//
//
//
///*
// * This is a mighty debugging tool.
// *
// * Before the Scheduler calls a task in sends pulses at PB13 to identify the
// * tasks.
// * 1 pulse = 1. TaskInit()-ed Task
// * 2 pulse = 2. TaskInit()-ed Task
// *
// * It is time consuming, but it makes it easy to see when the different tasks
// * are running and how long time thea need.
// *
// */
////   #define SHOW_TASKNUM
//
////===============================

#endif
